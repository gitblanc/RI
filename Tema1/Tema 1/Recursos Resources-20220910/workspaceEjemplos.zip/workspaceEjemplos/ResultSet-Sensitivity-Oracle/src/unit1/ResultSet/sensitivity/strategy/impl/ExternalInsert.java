package unit1.ResultSet.sensitivity.strategy.impl;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import unit1.ResultSet.sensitivity.strategy.ExecuteOperationStrategy;

public class ExternalInsert extends External implements ExecuteOperationStrategy {


	@Override
	public void doOperation(ResultSet rst) throws SQLException {
		showMessage("From SQLDeveloper, insert a new row ");
		showMessage("Then, ResultSet will be printed backwards");
		pressAnyKey();

	}
	
	
	@Override
	public String opName() {
		return "INSERT";

	}
	
	 private void showMessage(String string) {
		  System.out.println("**********************************************");
		  System.out.println("*          " + string + "             *");
		  System.out.println("**********************************************");
		  
	 }
	 
	 private void pressAnyKey() {
			System.out.println("Press Enter key to continue..."); 
			try { 
				System.in.read();
				
			} catch (Exception e) { } 
			
		}


	@Override
	public boolean getIsVisible(ResultSet rst, DatabaseMetaData meta) throws SQLException {
		return  meta.othersInsertsAreVisible(rst.getType());
	}

}
