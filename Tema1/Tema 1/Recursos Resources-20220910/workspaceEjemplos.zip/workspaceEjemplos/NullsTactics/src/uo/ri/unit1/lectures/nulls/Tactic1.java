package uo.ri.unit1.lectures.nulls;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Tactic1 {

	public static void main(String[] args) {

		Connection connection = null;
		String serverName = "localhost";
		String url = "jdbc:hsqldb:hsql://" + serverName + "/";
		String username = "sa";
		String password = "";
		ResultSet rs = null;

		// Create a connection to the database
		try {
			connection = DriverManager.getConnection(url, username, password);
			// Create a statement that will return updatable result sets
			Statement statement = connection.createStatement();
			rs = statement.executeQuery("SELECT * FROM TWorkOrders where id='008ed1c3-f1fc-4930-9f01-8a0f35c40bbe'");
						
			display(rs);
		
			} catch (SQLException e) {
				System.out.println("Error while operating the database " + e.getMessage());
			}
		finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private static void display(ResultSet rs) throws SQLException {
		while (rs.next()) {
			String id = rs.getString("id");
			String desc = rs.getString("description");
			int amount = rs.getInt("amount");
			System.out.println(id+" "+ desc+" "+amount);
		}
		
	}

}
