package unit1;

import unit1.Datasource.Application;

public class Main {

	public static void main(String[] args) {
		new Application().operate();

	}

}
