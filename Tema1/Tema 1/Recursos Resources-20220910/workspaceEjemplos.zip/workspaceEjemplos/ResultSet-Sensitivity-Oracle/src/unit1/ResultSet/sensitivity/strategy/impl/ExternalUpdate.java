package unit1.ResultSet.sensitivity.strategy.impl;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import unit1.ResultSet.sensitivity.strategy.ExecuteOperationStrategy;

public class ExternalUpdate extends External implements ExecuteOperationStrategy {


	@Override
	public void doOperation(ResultSet rst) throws SQLException {
		showMessage("From SQLDeveloper, change some value in the last AND first row");
		showMessage("Then, ResultSet will be printed backwards");
		pressAnyKey();

	}

	@Override
	public String opName() {
		return "UPDATE";

	}


	 private void showMessage(String string) {
		  System.out.println("**********************************************");
		  System.out.println("*          " + string + "             *");
		  System.out.println("**********************************************");
		  
	 }
	 
	 private void pressAnyKey() {
			System.out.println("Press Enter key to continue..."); 
			try { 
				System.in.read();
				
			} catch (Exception e) { } 
			
		}

	@Override
	public boolean getIsVisible(ResultSet rst, DatabaseMetaData meta) throws SQLException {

		return meta.othersUpdatesAreVisible(rst.getType());
	}

}
