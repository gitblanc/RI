package jndi.server;

import java.sql.SQLException;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

public class Server {
	
	public OracleDataSource createObject() throws SQLException {
		
		// Initialize Data Source Properties

		OracleDataSource ods = new OracleDataSource();
		
		ods.setDriverType("thin");
		ods.setServerName("156.35.94.99");
		ods.setDatabaseName("DESA");
		ods.setPortNumber(1521); 
		return ods;
	}
	
	public void bindName(String name, DataSource ds) throws NamingException {
		
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.rmi.registry.RegistryContextFactory");

		// Register the Data Source
		Context ctx = new InitialContext(env);
		ctx.bind(name, ds);

	}
	
	public void printProperties(DataSource ds) throws SQLException {
		OracleDataSource ods = (OracleDataSource) ds;
		System.out.println("Printing DataSource object properties!");
		System.out.println("Database name " + ods.getDatabaseName());
		System.out.println("DataSource name " + ods.getDataSourceName());
		System.out.println("Driver type " + ods.getDriverType());
		
	}
}
