package unit1.ResultSet.sensitivity.strategy;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;

public interface ExecuteOperationStrategy {
	void doOperation(ResultSet stmnt) throws SQLException;
	boolean getIsVisible(ResultSet rst, DatabaseMetaData meta)throws SQLException ;
	String opName();

	}
