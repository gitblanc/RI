package uo.ri.cws.domain.base;

public enum EntityStatus {
    ENABLED, DISABLED
}
