uo285176
Eduardo Blanco Bielsa
Ejercicio número 3 -> (gestión de nóminas, gestión de tipos de grupos profesionales, gestión de mecánicos ampliado)

COMENTARIOS:

Todos los test tanto de mecánicos como de grupos profesionales pasan estupendamente. Sin embargo, en generatePayrolls hay 
3 tests que no soy capaz de solucionar (no dan error, sino un fallo de assert en vuestros test). Por mucho que intento debugearlos 
para arreglarlos no saco nada en claro. Todos los demás test funcionan correctamente.