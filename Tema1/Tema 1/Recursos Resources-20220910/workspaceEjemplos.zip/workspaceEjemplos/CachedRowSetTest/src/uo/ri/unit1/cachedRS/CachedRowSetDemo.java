package uo.ri.unit1.cachedRS;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.SQLException;

import oracle.jdbc.rowset.OracleCachedRowSet;

public class CachedRowSetDemo {
 
  //Constant to hold file name used to store the CachedRowSet
  private final static String CRS_FILE_LOC ="cachedrs.crs";
 
  public static void main(String[] args) throws Exception {
    try {
      //Create serialized CachedRowSet
      writeCachedRowSet();
      //Create CachedRowSet from serialized object
      OracleCachedRowSet crs = readCachedRowSet();
      //Display values
      while(crs.next()){
        System.out.print("col1: " + crs.getInt("col1"));
        System.out.print(", col2: " + crs.getInt("col2"));
        System.out.print(", col3:" + crs.getInt("col3"));
        System.out.println();
      }
      //Close resource
      crs.close();
    } catch (SQLException se){
      se.printStackTrace();
    }catch (Exception ex) {
      ex.printStackTrace();
    }
  }//end main
 
  public static void writeCachedRowSet() throws Exception {
    //Instantiate a CachedRowSet object, set connection parameters
    OracleCachedRowSet crs = new OracleCachedRowSet();
  
    crs.setUrl("jdbc:oracle:thin:@156.35.94.99:1521:DESA");
    crs.setUsername("user??");
    crs.setPassword("pass??");
    //Set and execute the command. Notice the parameter query.
    String sql = "SELECT col1, col2, col3 ";
    sql = sql + "FROM Prueba WHERE col1=?";
    crs.setCommand(sql);
    crs.setInt(1,1);
    crs.execute();
    //Serialize CachedRowSet object.
    FileOutputStream fos = new FileOutputStream(CRS_FILE_LOC);
    ObjectOutputStream out = new ObjectOutputStream(fos);
    out.writeObject(crs);
    out.close();
    crs.close();
  }//end writeCachedRowSet()
    
  public static OracleCachedRowSet readCachedRowSet() throws Exception{
    //Read serialized CachedRowSet object from storage
    FileInputStream fis = new FileInputStream(CRS_FILE_LOC);
    ObjectInputStream in = new ObjectInputStream(fis);
    OracleCachedRowSet crs = (OracleCachedRowSet)in.readObject();
    fis.close();
    in.close();
    return crs;
  }//end readCachedRowSet()
  
}//end CachedRS