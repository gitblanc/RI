package uo.ri.cws.application.service.util.sql;

public class ConnectionData {
	public String url;
	public String driver;
	public String user;
	public String pass;
}
