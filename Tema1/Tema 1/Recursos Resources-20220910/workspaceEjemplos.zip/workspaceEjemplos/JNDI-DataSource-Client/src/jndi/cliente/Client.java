package jndi.cliente;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class Client {

	
	private DataSource dataSource = null;
	private String USERNAME = null;
	private String PASSWORD = null;
	
	public void operation() throws IOException, SQLException {
		String queryTable = "SELECT col1, col2, col3 FROM PRUEBA";
		Connection conn = null;
		System.out.println("Looking up data source ...");
		String jndiUrl = "ejemplo";
		try {
			dataSource = getDataSource(jndiUrl);
			getCredentials();
			
			
			conn = dataSource.getConnection(USERNAME, PASSWORD);

			Statement stmnt = conn.createStatement();
			ResultSet rst = stmnt.executeQuery(queryTable);
			printTableContent(rst);
		}
		catch(NamingException ne) {
			ne.printStackTrace();
		}
		finally {
			conn.close();
		}
	    
	} // operation

	
	private void getCredentials() throws IOException, SQLException {

		Properties prop = new Properties();
				
		InputStream input = new FileInputStream("config.properties");

		// load properties file
		prop.load(input);

		// get the property values
		USERNAME = prop.getProperty("USERNAME");
		PASSWORD = prop.getProperty("PASSWORD");

	}
	
	
	private void printTableContent(ResultSet r) throws SQLException {

		/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
		 * Printing query result set 
		 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
		while (r.next())
			System.out.println("col1 = " + r.getInt(1) + " col2 = " + r.getInt(2) + " col3 = " + r.getInt(3));

	}
	
	
	public DataSource getDataSource(String jndiUrl) throws NamingException {

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.rmi.registry.RegistryContextFactory");
		

		return (DataSource) new InitialContext(env).lookup(jndiUrl);

	}
	
    
    }
