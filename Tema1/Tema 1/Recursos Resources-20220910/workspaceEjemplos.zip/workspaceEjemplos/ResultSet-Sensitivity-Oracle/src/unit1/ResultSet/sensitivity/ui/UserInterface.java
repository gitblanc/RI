package unit1.ResultSet.sensitivity.ui;

import unit1.ResultSet.sensitivity.app.DatabaseOperations;
import unit1.ResultSet.sensitivity.strategy.impl.ExternalDelete;
import unit1.ResultSet.sensitivity.strategy.impl.ExternalInsert;
import unit1.ResultSet.sensitivity.strategy.impl.ExternalUpdate;
import unit1.ResultSet.sensitivity.strategy.impl.Insensitive;
import unit1.ResultSet.sensitivity.strategy.impl.InternalDelete;
import unit1.ResultSet.sensitivity.strategy.impl.InternalInsert;
import unit1.ResultSet.sensitivity.strategy.impl.InternalUpdate;
import unit1.ResultSet.sensitivity.strategy.impl.Sensitive;

/**
 * Determines user interaction with the application
 * 	- Prints a menu
 * 	- Reads user selection
 *  - Process user option
 *  	- Asks the user information needed to run the selection option
 *  	- Prints the result or an error message
 */
public class UserInterface {
	private static final int EXIT = 0;

	private Menu menu = new Menu();


	private DatabaseOperations dbo = new DatabaseOperations();
	
	public void run()  {
		int option = EXIT;
		do {
			menu.show();
			option = menu.readOption();
			processOption(option);
		} while (option != EXIT);
	}

	private void processOption(int option) {
		switch( option ) {
			case EXIT: return;
			case 1: dbo.operate(new Insensitive(), new InternalUpdate()); break;
			case 2: dbo.operate(new Sensitive(), new InternalUpdate()); break;
			case 3: dbo.operate(new Insensitive(), new InternalInsert()); break;// Se dice que debería ser visible cuando no es así pero además si se puede insertar. No entiendo.
			case 4: dbo.operate(new Sensitive(), new InternalInsert()); break; // Se dice que debería ser visible cuando no es así pero además si se puede insertar. No entiendo.
			case 5: dbo.operate(new Insensitive(), new InternalDelete()); break;
			case 6: dbo.operate(new Sensitive(), new InternalDelete()); break;

			case 7: dbo.operate(new Insensitive(), new ExternalUpdate()); break;
			case 8: dbo.operate(new Sensitive(), new ExternalUpdate()); break;
			case 9: dbo.operate(new Insensitive(), new ExternalInsert()); break;
			case 10: dbo.operate(new Sensitive(), new ExternalInsert()); break; // Se dice que debería ser visible cuando no es así.
			case 11: dbo.operate(new Insensitive(), new ExternalDelete()); break;
			case 12: dbo.operate(new Sensitive(), new ExternalDelete()); break; // Se dice que debería ser visible cuando no es así.
			
		}
	}
	
}
