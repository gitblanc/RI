package uo.ri.cws.application.ui.foreman.action;

import menu.Action;
import uo.ri.cws.application.business.BusinessException;

public class UpdateWorkOrderAction implements Action {

	@Override
	public void execute() throws BusinessException {
		// TODO Auto-generated method stub

	}

}
