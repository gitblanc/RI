package unit1.ResultSet.sensitivity.strategy.impl;


public abstract class External {

}
