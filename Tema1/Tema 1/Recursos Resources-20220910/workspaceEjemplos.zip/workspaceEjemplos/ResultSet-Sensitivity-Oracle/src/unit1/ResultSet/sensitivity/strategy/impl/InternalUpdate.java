package unit1.ResultSet.sensitivity.strategy.impl;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import unit1.ResultSet.sensitivity.strategy.ExecuteOperationStrategy;

public class InternalUpdate extends Internal implements ExecuteOperationStrategy {


	@Override
	public void doOperation(ResultSet rst) throws SQLException {
		int value;
		
		rst.beforeFirst();

		while (rst.next()) {
			value = rst.getInt(2) + 1;
			rst.updateInt(2, value);
			value = rst.getInt(3) + 1;
			rst.updateInt(3, value);
			rst.updateRow();
		}
		
	}
	
	@Override
	public String opName() {
		return "UPDATE";

	}

	@Override
	public boolean getIsVisible(ResultSet rst, DatabaseMetaData meta) throws SQLException {
		return meta.ownUpdatesAreVisible(rst.getType());
	}

//	
//	private void printTableContent(ResultSet r) throws SQLException {
//
//		/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
//		 * Printing query result set 
//		 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
//		r.beforeFirst();
//
//		while (r.next())
//			System.out.println("col1 = " + r.getInt(1) + " col2 = " + r.getInt(2) + " col3 = " + r.getInt(3));
//
//	}
//
//
//	 private void showMessage(String string) {
//		  System.out.println("**********************************************");
//		  System.out.println("*          " + string + "             *");
//		  System.out.println("**********************************************");
//		  
//	 }
//	 
//	 private void pressAnyKey() {
//			System.out.println("Press Enter key to continue..."); 
//			try { 
//				System.in.read();
//				
//			} catch (Exception e) { } 
//			
//		}

}
