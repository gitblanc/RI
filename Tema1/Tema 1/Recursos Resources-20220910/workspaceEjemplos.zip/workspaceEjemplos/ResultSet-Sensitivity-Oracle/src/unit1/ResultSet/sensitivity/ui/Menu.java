package unit1.ResultSet.sensitivity.ui;

import unit1.ResultSet.sensitivity.util.Console;

/**
 * Muestra un menu de opciones  por pantalla
 * Devuelve la opción elegida por el usuario
 */
public class Menu {
	private String[] options = {
			"Insensitive and internal update",
			"Sensitive and internal update",
			"Insensitive and internal insert",
			"Sensitive and internal insert",			
			"Insensitive and internal delete",
			"Sensitive and internal delete",
			"Insensitive and external update",
			"Sensitive and external update",
			"Insensitive and external insert",
			"Sensitive and external insert",			
			"Insensitive and external delete",
			"Sensitive and external delete",
		};
		
	public int readOption() {
		return Console.readInteger("Option");
	}

	public void show() {
		int i = 1;
		for(String line: options) {
			if ( "".equals(line) ) {
				Console.println("");
				continue;
			}
			
			Console.printf("\t%2d- %s\n", i++, line);
		}
		Console.printf("\n\t%2d- %s\n", 0, "Exit");
	}

}
