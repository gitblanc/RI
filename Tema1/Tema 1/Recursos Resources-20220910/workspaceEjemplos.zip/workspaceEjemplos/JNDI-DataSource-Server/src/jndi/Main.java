package jndi;

import java.sql.SQLException;

import javax.naming.NamingException;
import javax.sql.DataSource;

import jndi.server.Server;

public class Main {

	public static void main(String[] args) throws NamingException, SQLException {

		Server s = new Server();
		DataSource ds = s.createObject();
		s.printProperties(ds);
		s.bindName("ejemplo", ds);

	}

}
