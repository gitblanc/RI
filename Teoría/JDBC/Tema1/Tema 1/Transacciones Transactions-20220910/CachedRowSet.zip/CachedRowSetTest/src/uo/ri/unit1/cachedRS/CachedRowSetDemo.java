package uo.ri.unit1.cachedRS;

import java.sql.SQLException;

import javax.sql.rowset.CachedRowSet;

import oracle.jdbc.rowset.OracleCachedRowSet;

public class CachedRowSetDemo {

	private static OracleCachedRowSet crs;

	public static void createCachedRowSetDemo() throws SQLException {
		crs = new OracleCachedRowSet();

		crs.setUrl("jdbc:oracle:thin:@156.35.94.99:1521:DESA");
		crs.setUsername("lourdes");
		crs.setPassword("l0urd35");
	}

	public static void main(String[] args) throws Exception {
		try {
			// create
			createCachedRowSetDemo();
			// populate rowset
			populate();
			// display
			display(crs);
			// modify
			insert();

			display(crs);

			crs.acceptChanges();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}// end main

	private static void insert() throws SQLException {
		crs.moveToInsertRow();
		crs.updateInt(1, 209);
		crs.updateString(2, "Bus");
		crs.updateDouble(3, 50.0);
		crs.insertRow();

	}

	private static void display(CachedRowSet arg) throws SQLException {
		System.out.println("-----------------------------");
		arg.beforeFirst();

		while (arg.next()) {
			int col1 = arg.getInt(1);
			String col2 = arg.getString(2);
			double col3 = arg.getDouble(3);
			System.out.println(col1 + " " + col2 + " " + col3);
		}
	}

	private static void populate() throws SQLException {
		// Set and execute the command. Notice the parameter query.
		String sql = "SELECT id, nombre, preciohora ";
		sql = sql + "FROM TVehicleTypes ";
		crs.setCommand(sql);
//	    crs.setString(1, "1");
		crs.execute();
	}

}// end CachedRS