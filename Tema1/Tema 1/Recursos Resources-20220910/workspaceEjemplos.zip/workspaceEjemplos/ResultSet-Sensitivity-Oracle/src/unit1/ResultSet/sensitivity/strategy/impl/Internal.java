package unit1.ResultSet.sensitivity.strategy.impl;

public class Internal {
	public boolean isVisible;
}
