package uo.ri.cws.application.service.util.db;

public class ConnectionData {
	public String url;
	public String driver;
	public String user;
	public String pass;
}
