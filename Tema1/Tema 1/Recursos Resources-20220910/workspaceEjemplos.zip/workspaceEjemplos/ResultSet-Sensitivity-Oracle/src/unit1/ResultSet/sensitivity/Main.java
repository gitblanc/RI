package unit1.ResultSet.sensitivity;

import unit1.ResultSet.sensitivity.ui.UserInterface;

public class Main {
	
	public static void main(String[] args) {
		new UserInterface().run();
		}
}