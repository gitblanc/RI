package jndi;

import java.io.IOException;
import java.sql.SQLException;

import javax.naming.NamingException;

import jndi.cliente.Client;

public class Main {

	public static void main(String[] args) throws IOException, SQLException, NamingException {

		new Client().operation();
	}

}
