sh ./3.reset.sh

cp test.script.data test.script
