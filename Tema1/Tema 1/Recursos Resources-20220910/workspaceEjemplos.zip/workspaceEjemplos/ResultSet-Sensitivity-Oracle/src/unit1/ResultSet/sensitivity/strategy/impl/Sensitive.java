package unit1.ResultSet.sensitivity.strategy.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import unit1.ResultSet.sensitivity.strategy.CreateStatementStrategy;

public class Sensitive implements CreateStatementStrategy {

	@Override
	public Statement createStatement(Connection conn) throws SQLException {
		Statement stmnt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		// Set the statement fetch size to 1; default value is 10
	    //stmnt.setFetchSize (1);
		
		return stmnt; 
			
		
	}

}
