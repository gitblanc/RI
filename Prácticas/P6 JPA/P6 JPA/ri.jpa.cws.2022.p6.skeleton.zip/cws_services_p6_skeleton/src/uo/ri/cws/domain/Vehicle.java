package uo.ri.cws.domain;

public class Vehicle {
	private String plateNumber;
	private String make;
	private String model;

}
