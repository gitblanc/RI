package uo.ri.cws.ext.domain;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ContractTest.class, ContractTypeTest.class, PayrollTest.class,
	ProfessionalGroupTest.class })
public class AllTestsExtDomain {

}
