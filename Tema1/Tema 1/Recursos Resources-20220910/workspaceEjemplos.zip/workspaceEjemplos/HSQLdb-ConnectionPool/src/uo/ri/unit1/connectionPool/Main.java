package uo.ri.unit1.connectionPool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import org.hsqldb.jdbc.JDBCPool;

public class Main {

	static String URL = "jdbc:hsqldb:hsql://localhost";
	static String USERNAME = "SA";
	static String PASSWORD = "";
	
	
	public static void main(String[] args) throws SQLException {
		
		long ti = System.currentTimeMillis();
		Connection con = null, n_con = null;
		
		JDBCPool p = new JDBCPool(5);
		for (int i=0; i<100; i++) {
			p.setUrl(URL);
			p.setUser(USERNAME);
			p.setPassword(PASSWORD);
			con = p.getConnection(); 
			Statement s = con.createStatement();
			s.executeQuery("SELECT id, name, surname, dni FROM tmechanics");
			s.close();
			con.close();
		}
		long tf = System.currentTimeMillis();
		System.out.println("Time querying Statements with JDBCPool= " + Long.toString(tf-ti));
		

		long ti3 = System.currentTimeMillis();
		for (int i=0; i<100; i++) {
			n_con = DriverManager.getConnection(URL, USERNAME, PASSWORD); // conectar
			Statement s = n_con.createStatement();
			s.executeQuery("SELECT id, name, surname, dni FROM tmechanics");
			s.close();
			n_con.close();
		}
		long tf3 = System.currentTimeMillis();
		System.out.println("Time querying Statements with normal Connections= " + Long.toString(tf3-ti3));

	}

}
