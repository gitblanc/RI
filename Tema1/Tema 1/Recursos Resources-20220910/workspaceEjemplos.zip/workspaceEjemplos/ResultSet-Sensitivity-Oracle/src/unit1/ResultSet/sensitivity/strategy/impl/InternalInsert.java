package unit1.ResultSet.sensitivity.strategy.impl;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import unit1.ResultSet.sensitivity.strategy.ExecuteOperationStrategy;

public class InternalInsert extends Internal implements ExecuteOperationStrategy {


	@Override
	public void doOperation(ResultSet rst) throws SQLException {

		rst.moveToInsertRow();
		rst.updateInt(1, 111);
		rst.updateInt(2, 111);
		rst.updateInt(3, 111);

		rst.insertRow();
		
	}
	
	@Override
	public String opName() {
		return "INSERT";

	}

	@Override
	public boolean getIsVisible(ResultSet rst, DatabaseMetaData meta) throws SQLException {
		return meta.ownInsertsAreVisible(rst.getType());
	}

}
