package uo.ri.conf;


public class Factory {

	public static BusinessFactoryAdapter service;

}
