package uo.ri.unit1.Scroll;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ScrollableResultSetExample {

	private static ResultSet results = null;

	private static void display() {
		try {
			results.beforeFirst();
			// Display table data
			while (results.next()) {
				// Get the data from the current row using the column name
				String name = results.getString("name");
				String surname = results.getString("surname");
				String dni = results.getString("dni");
				String id = results.getString("id");
				System.out.println("Fetching data by column name for row " + results.getRow() + " : " + id + ", " + dni
						+ ", " + name + ", " + surname);
			}
		} catch (Exception e) {
			System.out.println("Error while operating on updatable ResultSet " + e.getMessage());
		}
	}
	
	private static void display_back() {
		try {
			results.afterLast();
			// Display table data
			while (results.previous()) {
				// Get the data from the current row using the column name
				String name = results.getString("name");
				String surname = results.getString("surname");
				String dni = results.getString("dni");
				String id = results.getString("id");
				System.out.println("Fetching data by column name for row " + results.getRow() + " : " + id + ", " + dni
						+ ", " + name + ", " + surname);
			}
		} catch (Exception e) {
			System.out.println("Error while operating on updatable ResultSet " + e.getMessage());
		}
	}
	public static void main(String[] args) {

		Connection connection = null;
		String serverName = "localhost";
		String url = "jdbc:hsqldb:hsql://" + serverName + "/";
		String username = "sa";
		String password = "";

		// Create a connection to the database
		try {
			connection = DriverManager.getConnection(url, username, password);
			connection.setAutoCommit(true);
		
			try {
				// Create a statement that will return updatable result sets
				Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);

				// Primary must be specified so that the result set is updatable
				results = statement.executeQuery("SELECT id, dni, name, surname FROM TMechanics");
	
				System.out.println("Table data prior results handling... ");
				
			} catch (Exception e) {
				System.out.println("ERROR connecting/reading the database " + e.getMessage());
			}

			// Display table data
			display();
	
			display_back();

			connection.commit();
			} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println("Error while operating the database " + e.getMessage());
		}

	}
}