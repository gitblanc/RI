package unit1.ResultSet.sensitivity.strategy.impl;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import unit1.ResultSet.sensitivity.strategy.ExecuteOperationStrategy;

public class InternalDelete extends Internal implements ExecuteOperationStrategy {


	@Override
	public void doOperation(ResultSet rst) throws SQLException {
		rst.last();
		rst.deleteRow();
	}
	
	@Override
	public String opName() {
		return "DELETE";

	}

	@Override
	public boolean getIsVisible(ResultSet rst, DatabaseMetaData meta) throws SQLException {
		return meta.ownDeletesAreVisible(rst.getType());
	}

	
}
