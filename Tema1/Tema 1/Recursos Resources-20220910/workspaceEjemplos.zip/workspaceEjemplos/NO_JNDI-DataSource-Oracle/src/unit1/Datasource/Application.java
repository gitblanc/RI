package unit1.Datasource;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class Application {
	private String queryTable = "SELECT col1, col2, col3 FROM PRUEBA";

	private Connection conn = null;
	
	public void operate() {
	
		try {
			conn = connect();
			Statement stmnt = conn.createStatement();
			ResultSet rst = stmnt.executeQuery(queryTable);	
			
			this.printTableContent(rst);
		} catch (IOException e) {
			System.out.println(e.getMessage()); e.printStackTrace();
		} catch (SQLException e) {
			printSQLException(e);
		} finally { 
			try { conn.close(); 
			} catch (SQLException e) {
				printSQLException(e); 	
			} // catch 	
		} // finally

	} // method

	
	private Connection connect() throws IOException, SQLException {

		Properties prop = new Properties();
		String URL = null;
		String USERNAME = null;
		String PASSWORD = null;
		
		InputStream input = new FileInputStream("config.properties");

		// load properties file
		prop.load(input);

		// get the property values
		URL = prop.getProperty("URL");
		USERNAME = prop.getProperty("USERNAME");
		PASSWORD = prop.getProperty("PASSWORD");

		
		OracleDataSource ods = new OracleDataSource();
		/* ods.setDriverType("thin");
		ods.setServerName("156.35.94.99");
		ods.setDatabaseName("DESA");
		ods.setPortNumber(1521); */
		
		// Alternative to previous 4 lines
		ods.setURL(URL);
		
		
		ods.setUser(USERNAME);
		ods.setPassword(PASSWORD);
		Connection conn = ods.getConnection();
		return conn;

	}

	private void printTableContent(ResultSet r) throws SQLException {

		/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
		 * Printing query result set 
		 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
		while (r.next())
			System.out.println("col1 = " + r.getInt(1) + " col2 = " + r.getInt(2) + " col3 = " + r.getInt(3));

	}
	
	 private void printSQLException(SQLException ex) {

		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				if (ignoreSQLException(((SQLException) e).getSQLState()) == false) {

					e.printStackTrace(System.err);
					System.err.println("SQLState: " + ((SQLException) e).getSQLState());

					System.err.println("Error Code: " + ((SQLException) e).getErrorCode());

					System.err.println("Message: " + e.getMessage());

					Throwable t = ex.getCause();
					while (t != null) {
						System.out.println("Cause: " + t);
						t = t.getCause();
					}
				}
			}
		}
	}

	private boolean ignoreSQLException(String sqlState) {

		if (sqlState == null) {
			System.out.println("The SQL state is not defined!");
			return false;
		}

		// X0Y32: Jar file already exists in schema
		if (sqlState.equalsIgnoreCase("X0Y32"))
			return true;

		// 42Y55: Table already exists in schema
		if (sqlState.equalsIgnoreCase("42Y55"))
			return true;

		return false;
	}
}



