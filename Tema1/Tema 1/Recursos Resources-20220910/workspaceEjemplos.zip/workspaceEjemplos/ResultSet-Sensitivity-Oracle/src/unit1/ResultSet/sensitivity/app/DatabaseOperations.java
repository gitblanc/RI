/**
 * https://download.oracle.com/otn_hosted_doc/jdeveloper/905/jdbc-javadoc/oracle/jdbc/OracleDatabaseMetaData.html
 */
package unit1.ResultSet.sensitivity.app;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import unit1.ResultSet.sensitivity.strategy.CreateStatementStrategy;
import unit1.ResultSet.sensitivity.strategy.ExecuteOperationStrategy;

public class DatabaseOperations {

	private String queryTable = "SELECT col1, col2, col3 FROM PRUEBA";

	protected Connection conn = null;
	
	
	// https://docs.oracle.com/javase/7/docs/api/java/sql/DatabaseMetaData.html
	// Implemented in the Oracle driver by
	// https://docs.oracle.com/cd/E11882_01/appdev.112/e13995/oracle/jdbc/OracleDatabaseMetaData.html

	
	public void operate(CreateStatementStrategy css, ExecuteOperationStrategy eos) {
		Connection conn = null;
		Statement stmnt = null;
		ResultSet rst = null;
		DatabaseMetaData meta = null;

		try {
			conn = connect();
			stmnt = css.createStatement(conn); 
			rst = stmnt.executeQuery(queryTable);
			meta = stmnt.getConnection().getMetaData();
			
			showMessage (" TABLE BEFORE  "+ eos.opName());
			printTableContent(rst);
			
			//isVisible = eos instanceof External?meta.othersUpdatesAreVisible(type):
				//meta.ownUpdatesAreVisible(type);
			showMessage(eos.opName() + " SHOULD BE "+ (eos.getIsVisible(rst, meta)?"VISIBLE":"NOT VISIBLE"));
			
			eos.doOperation(rst);

			this.printResultBackward(rst);	
		} catch (IOException e) {
			System.out.println(e.getMessage()); e.printStackTrace();
		} catch (SQLException e) {
			printSQLException(e);
		} finally { 
			try { conn.close(); 
			} catch (SQLException e) {
				printSQLException(e); 	
			} // catch 	
		} // finally

	} // method

	private Connection connect() throws IOException, SQLException {

		Properties prop = new Properties();
		String URL = null;
		String USERNAME = null;
		String PASSWORD = null;

		InputStream input = new FileInputStream("config.properties");

		// load properties file
		prop.load(input);

		// get the property values
		URL = prop.getProperty("URL");
		USERNAME = prop.getProperty("USERNAME");
		PASSWORD = prop.getProperty("PASSWORD");

		return DriverManager.getConnection(URL, USERNAME, PASSWORD);
		//meta = conn.getMetaData();

	}

	private void printTableContent(ResultSet r) throws SQLException {

		/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
		 * Printing query result set 
		 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
		r.beforeFirst();

		while (r.next())
			System.out.println("col1 = " + r.getInt(1) + " col2 = " + r.getInt(2) + " col3 = " + r.getInt(3));

	}
	
	private void printResultBackward(ResultSet r) {
		try {
			r.afterLast();

			while (r.previous())
				System.out.println("col1 = " + r.getInt(1) + " col2 = " + r.getInt(2) + " col3 = " + r.getInt(3));
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	

	 private void showMessage(String string) {
		  System.out.println("**********************************************");
		  System.out.println("*          " + string + "             *");
		  System.out.println("**********************************************");
		  
	 }
	
	
	private void printSQLException(SQLException ex) {

		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				if (ignoreSQLException(((SQLException) e).getSQLState()) == false) {

					e.printStackTrace(System.err);
					System.err.println("SQLState: " + ((SQLException) e).getSQLState());

					System.err.println("Error Code: " + ((SQLException) e).getErrorCode());

					System.err.println("Message: " + e.getMessage());

					Throwable t = ex.getCause();
					while (t != null) {
						System.out.println("Cause: " + t);
						t = t.getCause();
					}
				}
			}
		}
	}

	private boolean ignoreSQLException(String sqlState) {

		if (sqlState == null) {
			System.out.println("The SQL state is not defined!");
			return false;
		}

		// X0Y32: Jar file already exists in schema
		if (sqlState.equalsIgnoreCase("X0Y32"))
			return true;

		// 42Y55: Table already exists in schema
		if (sqlState.equalsIgnoreCase("42Y55"))
			return true;

		return false;
	}

}
